"""Scheduler "beat" do taskiq.

Substitui o antigo `tasks/scheduler.py` baseado em APScheduler.

No modelo antigo, este modulo mantinha uma instancia de AsyncIOScheduler
e publicava mensagens de "trigger" nas filas correspondentes em cada
disparo de cron. No taskiq, o cron fica declarado como um *label* direto
na propria task (`schedule=[{"cron": "..."}]`), e este processo apenas
descobre e dispara essas tasks na hora certa via `LabelScheduleSource`.

Executar com:
    taskiq scheduler tasks.scheduler:scheduler

Importante (ver docs/IMPROVEMENTS.md): rode **uma unica instancia** deste
processo por ambiente. Com mais de uma replica ativa, cada tick agendado
seria disparado em duplicidade (o taskiq nao faz leader election sozinho).
"""

# Importar o pacote `tasks` garante que todos os modulos de tasks (que
# declaram `schedule=[...]` via decorator) sejam carregados e registrados
# no broker antes do LabelScheduleSource le-los.
import tasks  # noqa: F401
from taskiq import TaskiqScheduler
from taskiq.schedule_sources import LabelScheduleSource

from tasks.taskiq_app import broker

scheduler = TaskiqScheduler(
    broker=broker,
    sources=[LabelScheduleSource(broker)],
)
