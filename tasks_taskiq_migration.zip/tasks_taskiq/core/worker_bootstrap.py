"""Hooks de ciclo de vida do worker taskiq.

Substitui o antigo `tasks/core/worker_bootstrap.py`, que registrava
`@app.on_startup` no FastStream. No taskiq, os eventos de ciclo de vida
do broker sao registrados via `broker.on_event(TaskiqEvents.WORKER_STARTUP)`
/ `WORKER_SHUTDOWN` (disparados apenas no processo *worker*, nao no
processo *scheduler* nem em quem apenas publica tasks).

A logica de inicializacao do banco (`init_db`) permanece identica a
original; apenas o mecanismo de registro do hook mudou.
"""

from taskiq import TaskiqEvents, TaskiqState

from geoloc_connector.core.database import init_db
from geoloc_connector.core.logger import app_logger

from tasks.taskiq_app import broker


def register_worker_bootstrap() -> None:
    @broker.on_event(TaskiqEvents.WORKER_STARTUP)
    async def init_worker_database(state: TaskiqState) -> None:
        try:
            await init_db()
            app_logger.info("worker_database_init_success")
        except Exception:
            app_logger.error("worker_database_init_failed", exc_info=True)
            raise
