"""Helper generico para agendamento por ETA (data/hora especifica).

Este e um modulo novo de suporte, nao substitui nenhuma task existente.
Ele encapsula o mecanismo de delay do `taskiq-aio-pika`
(ver `tasks/taskiq_app.py`, parametro `delay_queue`) para permitir agendar
qualquer task para rodar uma unica vez em um instante futuro arbitrario,
sem precisar de uma fonte de agendamento dinamica externa (Redis, Postgres
etc). Complementa o scheduler "beat" (cron, `tasks/scheduler.py`), que so
cobre agendamentos recorrentes fixos definidos em codigo.

Uso tipico: quando um chamador (por exemplo, a futura implementacao de
`tasks.regular_campaign.workflow`) sabe exatamente em que momento uma
execucao deveria (re)iniciar (ex.: inicio da proxima janela permitida),
ele pode chamar `schedule_task_at(...)` em vez de disparar a task
imediatamente ou esperar o proximo tick do cron.
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

from taskiq import AsyncTaskiqDecoratedTask, AsyncTaskiqTask

from geoloc_connector.core.logger import app_logger


async def schedule_task_at(
    task: AsyncTaskiqDecoratedTask[..., Any],
    run_at: datetime,
    *args: Any,
    **kwargs: Any,
) -> AsyncTaskiqTask[Any]:
    """Agenda `task` para rodar uma unica vez em `run_at` (ETA).

    Se `run_at` ja estiver no passado (ou for "agora"), a task e
    disparada imediatamente (delay=0), sem necessidade de tratamento
    especial por parte do chamador.
    """
    now = datetime.now(UTC)
    delay_seconds = max(0, int((run_at - now).total_seconds()))

    app_logger.info(
        "eta_task_scheduled",
        task_name=task.task_name,
        run_at=run_at.isoformat(),
        delay_seconds=delay_seconds,
    )

    if delay_seconds <= 0:
        return await task.kiq(*args, **kwargs)

    return await task.kicker().with_labels(delay=delay_seconds).kiq(*args, **kwargs)
