"""Retry de dispatches falhos de campanha regular.

Migrado de FastStream para taskiq. A logica de negocio (busca de
candidatos, criterios de esgotamento de retry/idade, transicoes de
status, contadores) e EXATAMENTE a mesma do arquivo original. A unica
mudanca e de transporte: o antigo `await broker.publish(payload,
queue=REGULAR_CAMPAIGN_QUEUE)` virou `await
run_regular_campaign_execution.kiq(payload)`.

O import de `run_regular_campaign_execution` e feito dentro da funcao
(import tardio) para evitar import circular: `tasks.regular_campaign.tasks`
importa `retry_failed_dispatches` deste modulo, entao este modulo nao pode
importar `tasks.py` no nivel de modulo.
"""

from datetime import UTC, datetime, timedelta

from geoloc_lib.repository.regular_campaign_execution_repository import (
    RegularCampaignExecutionRepository,
)
from geoloc_lib.schemas.regular_campaign_schema import (
    RegularCampaignExecutionReason,
    RegularCampaignExecutionStatus,
    RegularCampaignExecutionUpdate,
)
from geoloc_connector.core.logger import app_logger

from geoloc_connector.settings import settings


async def retry_failed_dispatches(*, now: datetime | None = None) -> str:
    reference = now or datetime.now(UTC)
    repository = RegularCampaignExecutionRepository()

    app_logger.info(
        "regular_campaign_dispatch_retry_start",
        reference=reference,
        limit=settings.REGULAR_CAMPAIGN_DISPATCH_RETRY_BATCH_SIZE,
    )
    executions = await repository.find_dispatch_retry_candidates(
        now=reference,
        limit=settings.REGULAR_CAMPAIGN_DISPATCH_RETRY_BATCH_SIZE,
    )
    app_logger.info(
        "regular_campaign_dispatch_retry_candidates_found",
        reference=reference,
        candidate_count=len(executions),
    )

    retried = 0
    moved_to_dlq = 0
    for execution in executions:
        age = reference - execution.created_at
        retry_exhausted = execution.dispatch_attempts > settings.REGULAR_CAMPAIGN_DISPATCH_MAX_RETRIES

        age_exhausted = age >= timedelta(seconds=settings.REGULAR_CAMPAIGN_DISPATCH_MAX_AGE_SECONDS)
        app_logger.info(
            "regular_campaign_dispatch_retry_candidate_evaluated",
            campaign_id=execution.campaign_id,
            execution_id=execution.execution_id,
            tenant_id=execution.tenant_id,
            dispatch_attempts=execution.dispatch_attempts,
            age_seconds=age.total_seconds(),
            retry_exhausted=retry_exhausted,
            age_exhausted=age_exhausted,
        )
        if retry_exhausted or age_exhausted:
            await repository.update_execution(
                execution.execution_id,
                execution.tenant_id,
                RegularCampaignExecutionUpdate(
                    status=RegularCampaignExecutionStatus.DLQ,
                    status_reason=RegularCampaignExecutionReason.DISPATCH_RETRY_EXHAUSTED,
                    finished_at=reference,
                ),
            )
            moved_to_dlq += 1
            app_logger.error(
                "regular_campaign_dispatch_dlq",
                campaign_id=execution.campaign_id,
                execution_id=execution.execution_id,
                tenant_id=execution.tenant_id,
                dispatch_attempts=execution.dispatch_attempts,
            )
            continue

        # Import tardio para evitar ciclo de import com tasks.py (ver docstring do modulo).
        from tasks.regular_campaign.tasks import run_regular_campaign_execution

        await run_regular_campaign_execution.kiq(
            {
                "campaign_id": execution.campaign_id,
                "execution_id": execution.execution_id,
                "tenant_id": execution.tenant_id,
            }
        )
        await repository.update_execution(
            execution.execution_id,
            execution.tenant_id,
            RegularCampaignExecutionUpdate(
                status=RegularCampaignExecutionStatus.PENDING_DISPATCH,
                status_reason=None,
                dispatch_attempts=execution.dispatch_attempts + 1,
                next_retry_at=reference,
            ),
        )
        retried += 1
        app_logger.info(
            "regular_campaign_dispatch_retried",
            campaign_id=execution.campaign_id,
            execution_id=execution.execution_id,
            tenant_id=execution.tenant_id,
            dispatch_attempts=execution.dispatch_attempts + 1,
        )

    app_logger.info(
        "regular_campaign_dispatch_retry_finished",
        reference=reference,
        retried=retried,
        dlq=moved_to_dlq,
    )
    return f"retried={retried} dlq={moved_to_dlq}"
