from geoloc_lib.schemas.regular_campaign_schema import (
    RegularCampaignExecutionReason,
)

PAUSE_REASONS = {
    RegularCampaignExecutionReason.OUTSIDE_ALLOWED_WINDOW,
    RegularCampaignExecutionReason.CAMPAIGN_PAUSED,
    RegularCampaignExecutionReason.QUOTA_EXHAUSTED,
}
