"""Workflow de execucao de campanha regular.

IMPORTANTE: por definicao desta entrega, este arquivo NAO contem a logica
de negocio (ela sera escrita separadamente). O que existe aqui e apenas a
interface publica esperada por `tasks.regular_campaign.tasks
.run_regular_campaign_execution`, para que o pacote permaneca importavel
e o restante da solucao (broker, scheduler, retry, tasks) funcione mesmo
antes da implementacao real ser adicionada.

Ao implementar `execute`, mantenha a assinatura abaixo (mesmos nomes e
tipos de parametro) para nao exigir mudancas em `tasks.py`.
"""

from __future__ import annotations


class RegularCampaignExecutionWorkflow:
    async def execute(self, campaign_id: str, execution_id: str, tenant_id: str) -> str:
        """Executa (ou retoma) uma execucao de campanha regular.

        Implementacao pendente - sera adicionada posteriormente.
        """
        raise NotImplementedError(
            "RegularCampaignExecutionWorkflow.execute ainda nao foi implementado."
        )
