"""Tasks de execucao/retry de campanha regular.

Migrado de FastStream para taskiq:
- `run_regular_campaign_execution`: mesma logica (extrai payload e chama
  `RegularCampaignExecutionWorkflow.execute`), apenas o decorator mudou.
  `retry_on_error=True` liga o `SmartRetryMiddleware` (configurado em
  `tasks/taskiq_app.py`) para esta task, cobrindo falhas tecnicas
  inesperadas que escapem do `workflow.execute` (ex.: bug, timeout de
  infraestrutura). Isso e uma camada COMPLEMENTAR ao retry de negocio de
  `regular_campaign/retry.py` (nao substitui): a maior parte das falhas
  de negocio (campanha pausada, quota esgotada, erro de segmentacao) e
  tratada internamente pelo workflow via atualizacao de status no banco,
  sem levantar excecao - entao esse middleware nao interfere nelas.
- `retry_failed_regular_campaign_dispatches`: mesma logica; o antigo
  "trigger" publicado por `tasks/scheduler.py` (APScheduler) foi
  substituido pelo label `schedule=[{"cron": ...}]`, que o
  `LabelScheduleSource` (`tasks/scheduler.py`) usa para disparar esta
  task automaticamente a cada minuto (scheduler "beat"). Deliberadamente
  SEM `retry_on_error`: ela ja roda a cada minuto via cron, entao um
  retry adicional no nivel de mensagem so adicionaria complexidade sem
  beneficio real.

`schedule_regular_campaign_execution` e uma funcao NOVA, puramente
aditiva: nao substitui nem altera as duas tasks acima. Ela existe para
que quem cria/reagenda uma execucao (por exemplo, a futura
implementacao de `regular_campaign/workflow.py`) possa optar por um
agendamento por ETA (`run_at` no futuro) em vez de disparo imediato,
usando `tasks.core.eta.schedule_task_at`.
"""

from datetime import datetime

from tasks.core.eta import schedule_task_at
from tasks.regular_campaign.retry import retry_failed_dispatches
from tasks.regular_campaign.workflow import RegularCampaignExecutionWorkflow
from tasks.taskiq_app import broker


@broker.task(task_name="regular_campaign.run_execution", retry_on_error=True, max_retries=3)
async def run_regular_campaign_execution(payload: dict[str, str]) -> str:
    campaign_id = payload["campaign_id"]
    execution_id = payload["execution_id"]
    tenant_id = payload["tenant_id"]

    workflow = RegularCampaignExecutionWorkflow()

    return await workflow.execute(campaign_id=campaign_id, execution_id=execution_id, tenant_id=tenant_id)


@broker.task(
    task_name="regular_campaign.retry_failed_dispatches",
    schedule=[{"cron": "*/1 * * * *"}],
)
async def retry_failed_regular_campaign_dispatches() -> str:
    return await retry_failed_dispatches()


async def schedule_regular_campaign_execution(
    *,
    campaign_id: str,
    execution_id: str,
    tenant_id: str,
    run_at: datetime | None = None,
) -> None:
    """Helper de producer para (re)disparar uma execucao de campanha.

    Quando `run_at` e informado, a execucao e agendada via ETA (fila de
    delay do taskiq) em vez de ser despachada imediatamente. Nao altera
    o comportamento de `run_regular_campaign_execution`; apenas decide
    *quando* ela sera enfileirada.
    """
    payload = {"campaign_id": campaign_id, "execution_id": execution_id, "tenant_id": tenant_id}
    if run_at is None:
        await run_regular_campaign_execution.kiq(payload)
        return
    await schedule_task_at(run_regular_campaign_execution, run_at, payload)
