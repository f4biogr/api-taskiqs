"""Tasks de geracao de relatorios.

Migrado de FastStream para taskiq. Os corpos das funcoes (chamadas ao
`ReportService` e tratamento de excecao) sao identicos ao original.

O antigo `tasks/scheduler.py` (APScheduler) publicava um "trigger" em
cada fila de relatorio a cada minuto; agora cada task declara seu proprio
cron via o label `schedule=[{"cron": ...}]`, e o scheduler "beat"
(`tasks/scheduler.py`, com `LabelScheduleSource`) cuida do disparo.

`retry_on_error=True` liga o `SmartRetryMiddleware` (configurado em
`tasks/taskiq_app.py`) para as tres tasks abaixo: em caso de excecao
(ex.: falha transitoria ao consultar dados para o relatorio), ha um
reenvio rapido com backoff antes do proximo tick do cron. `max_retries=2`
foi escolhido propositalmente baixo, ja que essas tasks tambem sao
re-disparadas a cada minuto pelo scheduler beat.
"""

from geoloc_connector.core.logger import app_logger

from geoloc_connector.services.report_service import ReportService

from tasks.taskiq_app import broker


def get_report_service() -> ReportService:
    return ReportService()


@broker.task(
    task_name="reports.generate_hourly_report",
    schedule=[{"cron": "*/1 * * * *"}],
    retry_on_error=True,
    max_retries=2,
)
async def generate_hourly_report_task() -> str:
    try:
        report_service = get_report_service()
        return await report_service.generate_hourly_report()
    except Exception:
        app_logger.error("hourly_report_error", exc_info=True)
        raise


@broker.task(
    task_name="reports.generate_daily_report",
    schedule=[{"cron": "*/1 * * * *"}],
    retry_on_error=True,
    max_retries=2,
)
async def generate_daily_report_task() -> str:
    try:
        report_service = get_report_service()
        return await report_service.generate_daily_report()
    except Exception:
        app_logger.error("daily_report_error", exc_info=True)
        raise


@broker.task(
    task_name="reports.generate_message_report",
    schedule=[{"cron": "*/1 * * * *"}],
    retry_on_error=True,
    max_retries=2,
)
async def generate_message_report_task() -> str:
    try:
        report_service = get_report_service()
        return await report_service.generate_message_report()
    except Exception:
        app_logger.error("message_report_error", exc_info=True)
        raise
