"""Configuracao compartilhada do broker taskiq.

Substitui o antigo `tasks/faststream_app.py` (FastStream + RabbitBroker).

Diferenca de modelo: no FastStream cada dominio tinha sua propria
RabbitQueue (msisdn.process, campaign.exec, campaign.retry, reports.*).
No taskiq o roteamento e feito por `task_name` sobre um unico broker/fila
(ver `docs/IMPROVEMENTS.md` para a discussao sobre isolar filas por
dominio, caso seja necessario escalar workers de forma independente).

O `delay_queue` habilita o mecanismo nativo de ETA do taskiq-aio-pika:
mensagens "atrasadas" ficam paradas nessa fila (com TTL) e voltam para a
fila principal quando o tempo configurado expira. Isso e usado por
`tasks.core.eta.schedule_task_at` para agendamentos pontuais (ETA),
complementando o scheduler "beat" (cron) configurado em `tasks/scheduler.py`.

Retry nativo (middleware): `SmartRetryMiddleware` foi adicionado como
camada COMPLEMENTAR ao retry de negocio ja existente em
`regular_campaign/retry.py` (que continua intocado). Ele cobre falhas
tecnicas inesperadas que escapam durante a execucao ao vivo de uma task
(ex.: excecao nao tratada por bug, timeout de infraestrutura) fazendo um
reenvio rapido com backoff exponencial + jitter. Ele NAO substitui
`retry.py`: a maioria das falhas de negocio tratadas pelo workflow
(campanha pausada, quota esgotada, erro de segmentacao etc.) e resolvida
internamente via atualizacao de status no banco, sem levantar excecao -
logo nao ha nada para esse middleware capturar nesses casos. Ver
`docs/IMPROVEMENTS.md` para a discussao completa.

Como o middleware nao recebeu `schedule_source`, seus reenvios tambem
usam o mesmo mecanismo de `delay` (fila de delay acima) - nao ha
dependencia nova de infraestrutura (Redis etc).
"""

from taskiq import SmartRetryMiddleware
from taskiq_aio_pika import AioPikaBroker, Queue

from geoloc_connector.settings import settings

QUEUE_NAME = "tasks.geoloc_connector"
DELAY_QUEUE_NAME = "tasks.geoloc_connector.delay"

broker = AioPikaBroker(
    settings.CELERY_BROKER_URL,
    task_queues=[Queue(name=QUEUE_NAME)],
    delay_queue=Queue(name=DELAY_QUEUE_NAME),
).with_middlewares(
    SmartRetryMiddleware(
        default_retry_count=3,
        default_delay=5,
        use_jitter=True,
        use_delay_exponent=True,
        max_delay_exponent=60,
    ),
)
