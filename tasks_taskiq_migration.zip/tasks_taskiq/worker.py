"""Entry point do processo worker taskiq.

Substitui o antigo `tasks/worker.py` (FastStream `app` + partida do
APScheduler). No taskiq nao existe um objeto "app" separado do broker:
o worker e iniciado apontando direto para o broker, e a descoberta de
tasks acontece importando os modulos que as declaram (feito aqui via
`import tasks`, que executa `tasks/__init__.py`).

Executar com:
    taskiq worker tasks.worker:broker
"""

import tasks  # noqa: F401  (garante o import de todos os modulos de tasks)
from geoloc_connector.core.logger import app_logger

from tasks.core.worker_bootstrap import register_worker_bootstrap
from tasks.taskiq_app import broker

register_worker_bootstrap()

app_logger.info("worker_module_loaded")
