"""Task de processamento de arquivo MSISDN.

Migrado de FastStream (`@broker.subscriber(MSISDN_QUEUE)`) para taskiq
(`@broker.task(...)`). O corpo da funcao nao foi alterado.

`retry_on_error=True` habilita o `SmartRetryMiddleware` (configurado em
`tasks/taskiq_app.py`) para esta task: em caso de excecao (ex.: falha
transitoria de rede/MinIO), ela e reenviada automaticamente com backoff,
antes de desistir e deixar a falha propagar de fato.
"""

from geoloc_connector.core.logger import app_logger

from geoloc_connector.services.file_service import FileService

from tasks.taskiq_app import broker


def get_file_service() -> FileService:
    return FileService()


@broker.task(task_name="msisdn.process_msisdn_file", retry_on_error=True, max_retries=3)
async def process_msisdn_file(payload: dict[str, str]) -> str:
    file_url = payload["file_url"]
    list_id = payload["list_id"]
    tenant_id = payload["tenant_id"]

    app_logger.info("msisdn_file_task_start", file_url=file_url, list_id=list_id, tenant_id=tenant_id)

    try:
        service = get_file_service()

        total_lines = await service.process_msisdn_file_from_minio(
            file_url=file_url, list_id=list_id, tenant_id=tenant_id
        )

        app_logger.info(
            "msisdn_file_task_success",
            file_url=file_url, list_id=list_id, tenant_id=tenant_id, total_lines=total_lines
        )
        return f"File processed with list_id: {list_id}, lines: {total_lines}"
    except Exception:
        app_logger.error(
            "msisdn_file_task_failed",
            exc_info=True, file_url=file_url, list_id=list_id, tenant_id=tenant_id
        )
        raise
